<!DOCTYPE html>
<html>
<head>
	<title>star</title>
</head>
<style type="text/css">
	.bdy{
		display: flex;
    justify-content: center;
    margin-top: 104px;
	}

</style>
<body>
<div class="container bdy">
	<?php

	$n=3;
	$z=1;
	$d=5;

	for($i=1; $i<=$n; $i++){

		for($k=($n-1); $k>=$i; $k--){
			echo " &nbsp;  ";
		}
		for($j=1; $j<=$z; $j++){
			echo "*";

		

		}
		$z+=2;

		
		echo "<br />";

	}

	for($i=0; $i<=4; $i++){
		

			for($j=1; $j<=7; $j++){


				if( $j>=4 && $j<=4 ){

					echo "&";
				}
				echo "&nbsp;";
			}
		echo "<br />";

	}

	?>
</div>

</body>
</html>