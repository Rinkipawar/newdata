<?php
session_start();

include 'conection.php';

$uid = $_SESSION['uid'];

$time =time();
$res = mysqli_query($con,"select * from statusdb");
//$id = $_GET['id'];
$i=1;
$html = '';
  	while($row = mysqli_fetch_array($res)){
  		$status = 'offline';
  		$class = "btn-outline-danger";
  		if($row['last_login'] > $time){
  			$status = 'online';
  			$class = "btn-outline-success";
  		}

  		$html.='<tr>
  		<td>'.$i.'</td>
  		<td>'.$row['username'].'</td>
  		<td><button type="button" class="btn 
      '.$class.'">
  			'.$status.'
  		</button></td>
        
</tr>';

  		$i++;
  	}

  	echo $html;
?>