 <?php
session_start();

include 'conection.php';

if(!isset($_SESSION['uid'])){
 header('location:index.php');
 die();
}
$time= time();
$selectquery = "select * from statusdb";
$query = mysqli_query($con,$selectquery);
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
  	<div class="container p-5">
  		<h2 class="text-center text-info">User status</h2>
  		<h2 class="text-center text-info"><a href="logout.php" class="btn btn-outline-primary">logout</a></h2>
  		<table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">username</th>
      <th scope="col">status</th>
    </tr>
  </thead>
  <tbody id="usr_grid">
  	<?php
  	$i=1;
  	while($row = mysqli_fetch_array($query)){
  		
      $status = 'offline';
      $class = "btn-outline-danger";
      if($row['last_login'] >$time){
        $status = 'online';
        $class = "btn-outline-success";
      }
  		?>

  		<tr>
  		<td><?php echo $i ?></td>
  		<td><?php echo $row['username'];?></td>
  		<td><button type="button" class="btn 
  			<?php  echo $class ?>">
  		<?php echo $status ?></button></td>
        
</tr>

  		<?php
  		$i++;
  	}
  	?>
    
  </tbody>
</table>
  		
  	</div>
  	 



  <script src="https://code.jquery.com/jquery-3.4.1.min.js"  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo"  crossorigin="anonymous"></script>

 <script>

      function updateUserdbStatus(){
        jQuery.ajax({
          url:'update.php',
          success:function(){

          }
        });
      }


        function getUserdbStatus(){

        jQuery.ajax({
          url:'get_user_status.php',

          success:function(result){

            jQuery('#usr_grid').html(result);

          }
        });
      }

     
       setInterval(function(){
        updateUserdbStatus();

      },3000);

        setInterval(function(){
        getUserdbStatus();

      },5000);

        

    </script>

  </body>
  </html>
 