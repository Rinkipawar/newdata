<?php
session_start();

include 'conection.php';

$uid = $_SESSION['uid'];
$time = time()+10;

$res = mysqli_query($con,"update statusdb set last_login=$time where id=$uid");
?>